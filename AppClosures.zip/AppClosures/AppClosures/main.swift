//
//  main.swift
//  AppClosures
//
//  Created by Michael Steve Espinoza Perez on 30/04/23.
//

import Foundation

var letters = ["North", "East", "West", "South"]

let twoletters = letters.map({
   (state: String) -> String in
    return state.prefix(2).uppercased()
    
})

let stletters = letters.map() {
    $0.prefix(2).uppercased()
}
print(stletters)

//-----OTRA LINEA DE CODIGO-----//
print("----------------------------")

let shorthand: (String, String, String, String) -> String = { $3 }
print("Result:", shorthand("100", "200", "900", "143"))
print("----------------------------")


let sub = {
    (no1: Int, no2: Int, no3: Int, no4: Int, no5: Int) -> Int in
   return no1 - no2 + no3 - no4 + no5
}

let digits = sub(10,20,30,50,87)
print(digits)
print("----------------------------")

func calcDecrement(forDecrement total: Int) -> () -> Int {
   var overallDecrement = 100
   return {
      overallDecrement -= total
      print(overallDecrement)
      return overallDecrement
   }
}

let decrem = calcDecrement(forDecrement: 18)
decrem()
decrem()
decrem()
print("----------------------------")

