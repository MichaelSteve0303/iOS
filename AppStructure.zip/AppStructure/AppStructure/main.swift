//
//  main.swift
//  AppStructure
//
//  Created by Michael Steve Espinoza Perez on 30/04/23.
//

import Foundation

struct studentMarks {
   var mark1 = 100
   var mark2 = 200
   var mark3 = 300
   var mark4 = 400
}

let marks = studentMarks()
print("---------------------------------")
print("Mark1 is \(marks.mark1)")
print("Mark2 is \(marks.mark2)")
print("Mark3 is \(marks.mark3)")
print("Mark4 is \(marks.mark4)")

//Otra parte del codigo//

struct MarksStruct {
   var mark: Int

   init(mark: Int) {
      self.mark = mark
   }
}

var aStruct = MarksStruct(mark: 98)
var bStruct = aStruct     // aStruct and bStruct are two structs with the same value!
bStruct.mark = 97

print("---------------------------------")
print(aStruct.mark)      // 98
print(bStruct.mark)      // 97
print("---------------------------------")

//............

struct markStruct {
   var mark1: Int
   var mark2: Int
   var mark3: Int
   var mark4: Int
   /*var mark5: Int
   var mark6: Int
   var mark7: Int
   var mark8: Int*/
   
    init(mark1: Int, mark2: Int, mark3: Int, mark4: Int) {
      self.mark1 = mark1
      self.mark2 = mark2
      self.mark3 = mark3
      self.mark4 = mark4
   }
}

var fail = markStruct(mark1: 34, mark2: 42, mark3: 13, mark4: 63)

print(fail.mark1)
print(fail.mark2)
print(fail.mark3)
print(fail.mark4)
