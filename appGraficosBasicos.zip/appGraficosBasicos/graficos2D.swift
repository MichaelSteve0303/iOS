//
//  graficos2D.swift
//  appGraficosBasicos
//
//  Created by Michael Steve Espinoza Perez on 12/05/23.
//

import UIKit

class graficos2D: UIView {
    
    override func draw(_ rect: CGRect) {
        let canvas = UIGraphicsGetCurrentContext()
        
        canvas?.setLineWidth(5.0)
        canvas?.setStrokeColor(UIColor.blue.cgColor)
        
       // canvas?.setStrokeColor(#colorLiteral(red:1.0,green:0.0,blue:0.0, alpha:1.0))
        
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let componentes:[CGFloat]=[CGFloat(Float.random(in: 0.0..<1.0)), CGFloat(drand48()),0.0,1.0]
        
        let color = CGColor(colorSpace: colorSpace, components: componentes)
        
        canvas?.move(to: CGPoint(x: 0, y: 0))
        canvas?.addLine(to: CGPoint(x: 200, y: 300))
                       // control1: CGPoint(x: 100, y: 0),
                       // control2: CGPoint(x: 100, y: 300))
        
        canvas?.strokePath()
        
        //Dibujar un rectangulo
        
        let rectangulo = CGRect(x: rect.width/2, y: 50, width: rect.width-10, height: rect.height/2)
        canvas?.addRect(rectangulo)
        canvas?.strokePath()
        canvas?.setFillColor(UIColor.orange.cgColor)
        canvas?.fill(rectangulo)
    }


    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
