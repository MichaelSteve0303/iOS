//
//  ViewController.h
//  AppPicker2Columnas
//
//  Created by Michael Steve Espinoza Perez on 30/03/23.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIPickerViewDelegate, UIPickerViewDataSource>

@property (weak, nonatomic) IBOutlet UILabel *label1;

@property (weak, nonatomic) IBOutlet UIImageView *imageView;


@property (weak, nonatomic) IBOutlet UIPickerView *pickerView1;


@end

