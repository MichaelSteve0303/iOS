//
//  AppDelegate.h
//  AppPicker2Columnas
//
//  Created by Michael Steve Espinoza Perez on 30/03/23.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

