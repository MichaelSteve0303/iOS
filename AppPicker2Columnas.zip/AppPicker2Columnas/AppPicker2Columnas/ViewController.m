//
//  ViewController.m
//  appPicker2Columnas
//
//  Created by Michael Steve on 31/03/23.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSArray *productos;
    NSArray *colores;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    productos = @[@"PantallaLCD",@"ipad",@"BICI_2",@"moto1",@"carro1",@"camioneta1"];
    
    colores = @[@"Rojo 🦞",@"Verde🦎",@"Azul",@"Gris",@"Anaranjado",@"Aleatorio"];
    
    _pickerView1.delegate = self;
    _pickerView1.dataSource = self;
//lineas de abajo
  
//codigo terminante..
    
    _label1.text = [NSString stringWithFormat:@" %@, %@",[productos objectAtIndex:0],[colores objectAtIndex:0]];
    
    _imageView.image = [UIImage imageNamed:@"PantallaLCD"];
    
    UIColor *color = [UIColor colorWithRed:0 green:155 blue:150 alpha:  1];
    
    self.view.backgroundColor = color;
    
    NSLog(@"%@", _label1.text);
    
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 2;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if(component == 0)
        return productos.count;
    else
        return colores.count;
    
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if(component == 0)
        return [productos objectAtIndex:row];
    else
        return  colores[row];
    return nil;
}
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    
    if (component == 0) {
        NSString *productoSeleccionado = productos[row];
        NSString *nombreImagen = [NSString stringWithFormat:@"%@.jpg", productoSeleccionado];
        UIImage *imagen = [UIImage imageNamed:nombreImagen];
        _imageView.image = imagen;
    }

    _label1.text = [NSString stringWithFormat:@"%@ , %@",[productos objectAtIndex:[_pickerView1 selectedRowInComponent:0]],[colores objectAtIndex:[_pickerView1 selectedRowInComponent:1]]];
    
    unsigned long int color =  [colores indexOfObject:[colores objectAtIndex:[_pickerView1 selectedRowInComponent:1]]];
    
    switch(color)
    {
        case 0:
            self.imageView.backgroundColor = [UIColor redColor];
            break;
        case 1:
            self.imageView.backgroundColor = [UIColor greenColor];
            break;
        case 2:
            self.imageView.backgroundColor = [UIColor blueColor];
            break;
        case 3:
            self.imageView.backgroundColor = [UIColor lightGrayColor];
            break;
        case 4:
            self.imageView.backgroundColor = [UIColor orangeColor];
            break;
        case 5:
            srand((unsigned int) time(NULL));
            UIColor *colorAleatorio = [UIColor colorWithRed:(rand()%255 / 255.0) green:(rand()%255 / 255.0) blue:(rand()%255 / 255.0) alpha:1.0];
            
            self.imageView.backgroundColor = colorAleatorio;
            break;
    }
}
@end
