//
//  appSwiftUI_1App.swift
//  appSwiftUI_1
//
//  Created by Michael Steve Espinoza Perez on 05/06/23.
//

import SwiftUI

@main
struct appSwiftUI_1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
