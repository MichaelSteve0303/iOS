//
//  ViewController.swift
//  appSceneKitMoverLuzCamara
//
//  Created by Michael Steve Espinoza Perez on 23/05/23.
//

import UIKit
import SceneKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var imageView: UIImageView!
    
    
    @IBOutlet weak var segmentoLuces: UISegmentedControl!
    
    @IBOutlet weak var sliderLuzX: UISlider!
    
    @IBOutlet weak var sliderLuzY: UISlider!
    
    @IBOutlet weak var sliderLuzZ: UISlider!
    
    @IBOutlet weak var sliderCamaraX: UISlider!
    
    @IBOutlet weak var sliderCamaraY: UISlider!
    
    @IBOutlet weak var sliderCamaraZ: UISlider!
    
    
    var tipoLuz : String?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tipoLuz = "Directional"
        dibujaobjeto3D()
        
    }
    
    
    @IBAction func sliderLuzX(_ sender: UISlider) {
        sliderLuzX.value = sender.value
        dibujaobjeto3D()
    }
    
    
    @IBAction func sliderLuzY(_ sender: UISlider) {
        sliderLuzY.value = sender.value
        dibujaobjeto3D()
    }
    
    
    @IBAction func sliderLuzZ(_ sender: UISlider) {
        sliderLuzZ.value = sender.value
        dibujaobjeto3D()
    }
    
    
    @IBAction func sliderCamaraX(_ sender: UISlider) {
        sliderCamaraX.value = sender.value
        dibujaobjeto3D()
    }
    
    
    @IBAction func sliderCamaraY(_ sender: UISlider) {
        sliderCamaraY.value = sender.value
        dibujaobjeto3D()
    }
    
    
    @IBAction func sliderCamaraZ(_ sender: UISlider) {
        sliderCamaraZ.value = sender.value
        dibujaobjeto3D()
    }
    
    
    @IBAction func segmentoTipoLuz(_ sender: UISegmentedControl) {
        let indice : Int = segmentoLuces.selectedSegmentIndex
        
        switch indice{
        case 0: tipoLuz = "ambient"
            
        case 1: tipoLuz = "directional"
            
        case 2: tipoLuz = "omni"
            
        case 3: tipoLuz = "spot"
            
        default: tipoLuz = "ambient"
            
        }
        
        dibujaobjeto3D()
    }
    
    
    func dibujaobjeto3D()
    {
        let sceneView = SCNView(frame: self.imageView.frame)
        self.imageView.addSubview(sceneView)
        let scene = SCNScene()
        sceneView.scene = scene
        let camara = SCNCamera()
        let camaraNodo = SCNNode()
        camaraNodo.camera = camara
        
        //VISTA DE FRENTE
        camaraNodo.position = SCNVector3(self.sliderCamaraX.value, sliderCamaraY.value, sliderCamaraZ.value)
        
        let luz = SCNLight()
       // luz.type = SCNLight.LightType.omni
        luz.type = SCNLight.LightType(rawValue: tipoLuz!)
        luz.spotInnerAngle = 30.0
        luz.spotOuterAngle = 70.0
        
        luz.castsShadow = true
        let luzNodo = SCNNode()
        luzNodo.light = luz
        
        luzNodo.position = SCNVector3(sliderLuzX.value, sliderLuzY.value,sliderLuzZ.value)
        
        let geometriaCubo = SCNBox(width: 1.0, height: 1.0, length: 1.0, chamferRadius: 0.1)
        
        let cuboNodo = SCNNode(geometry: geometriaCubo)
        
        //ESFERA
        
        let sphereGeometry = SCNSphere(radius: 0.5)
        let sphereNode = SCNNode(geometry: sphereGeometry)
        
        
        let constraint = SCNLookAtConstraint(target: cuboNodo)
        constraint.isGimbalLockEnabled = true
        
        camaraNodo.constraints = [constraint]
        luzNodo.constraints = [constraint]
        
        let planoGeometria = SCNPlane(width: 50.0/3, height: 50.0/3)
        
        let planoNodo = SCNNode(geometry: planoGeometria)
        
        planoNodo.eulerAngles = SCNVector3( GLKMathDegreesToRadians(-90), 0, 0.0)
        
        planoNodo.position = SCNVector3(x: 0.0, y: -0.5, z: 0.0)
        
        //COLOR DEL CUBO
        let materialCubo = SCNMaterial()
        materialCubo.diffuse.contents = UIColor.systemCyan
        geometriaCubo.materials = [materialCubo]
        cuboNodo.position = SCNVector3(0.5,0,0)
        
        //COLOR DE LA ESFERAS
        sphereGeometry.firstMaterial?.diffuse.contents = UIColor.systemGreen
        
        sphereNode.position = SCNVector3(2.0,0,0)
        
        
        //COLOR DEL PLANO
        let materialPlano = SCNMaterial()
        materialPlano.diffuse.contents = UIColor.yellow
        planoGeometria.materials = [materialPlano]
        
        //AGREGAMOS NODOS
        scene.rootNode.addChildNode(luzNodo)
        scene.rootNode.addChildNode(camaraNodo)
        scene.rootNode.addChildNode(cuboNodo)
        scene.rootNode.addChildNode(sphereNode)
        scene.rootNode.addChildNode(planoNodo)
        
        
        
        
        
        
                                    
    }


}

