//
//  main.swift
//  appClasses
//
//  Created by Michael Steve Espinoza Perez on 30/04/23.
//

import Foundation

class MarksStruct {
   var mark: Int
    var mark2: Int
    init(mark: Int, mark2:Int) {
      self.mark = mark
        self.mark2 = mark2
   }
}

class studentMarks {
   var mark = 300
   var mark2 = 400
}

let marks = studentMarks()
print("-----------------------------------")
print("Mark is \(marks.mark)")
print("Mark2 is \(marks.mark2)")
print("-----------------------------------")

//--------------------------//
//Otro codigo//
class SampleClass {
    let myProperty: String
    init(property: String) {
        myProperty = property
    }
}

extension SampleClass: Equatable {
    static func == (lhs: SampleClass, rhs: SampleClass) -> Bool {
        return lhs.myProperty == rhs.myProperty
    }
}

let spClass1 = SampleClass(property: "Hello")
let spClass2 = SampleClass(property: "Hello")

print("\(spClass1)") // "SampleClass: Hello"
print("\(spClass2)") // "SampleClass: Hello"

if spClass1 == spClass2 {
    print("-----------------------------------")
    print("spClass1 y spClass2 son equivalentes")
    print("-----------------------------------")
} else {
    print("-----------------------------------")
    print("spClass1 y spClass2 no son equivalentes")
    print("-----------------------------------")
}


