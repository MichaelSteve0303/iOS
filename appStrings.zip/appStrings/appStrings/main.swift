//
//  main.swift
//  appStrings
//
//  Created by Michael Steve Espinoza Perez on 30/04/23.
//

import Foundation

// String creation using String literal
var stringA = "Hola estamos en Swift"
print( stringA )

// String creation using String instance
var stringB = String("Esta es la clase de iOS")
print( stringB )

//Multiple line string

let stringC = """
Hola esto es algo muy
diferente a como
pensabes, solo debes
programar

"""
print(stringC)

// Empty string creation using String literal
var stringAA = ""

if stringAA.isEmpty {
   print( "stringA esta vacio" )
} else {
   print( "stringA no esta vacio" )
}

// Empty string creation using String instance
let stringBB = String()

if stringBB.isEmpty {
   print( "stringB esta vacio" )
} else {
   print( "stringB no esta vacio" )
}

