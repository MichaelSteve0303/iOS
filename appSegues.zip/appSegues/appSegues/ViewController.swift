//
//  ViewController.swift
//  appSegues
//
//  Created by Michael Steve Espinoza Perez on 30/05/23.
//

import UIKit

var cadena = ""

class ViewController: UIViewController {
    
    
    @IBOutlet weak var texto1: UITextField!
    
    
    @IBAction func botonIrVista2(_ sender: UIButton) {
        
        if texto1.text != ""{
            cadena = texto1.text!
            performSegue(withIdentifier: "segue1", sender: self)
        }
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

