//
//  ViewController.h
//  appEXPPickerView
//
//  Created by Michael Steve Espinoza Perez on 04/04/23.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource>

@property (weak, nonatomic) IBOutlet UITextField *textField;

@property (weak, nonatomic) IBOutlet UIPickerView *pickerView;

@property (weak, nonatomic) IBOutlet UILabel *validationLabel;

- (IBAction)showMessage:(id)sender;


@end

