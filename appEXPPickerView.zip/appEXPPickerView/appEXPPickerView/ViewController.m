//
//  ViewController.m
//  appEXPPickerView
//
//  Created by Michael Steve Espinoza Perez on 04/04/23.
//

#import "ViewController.h"

@interface ViewController ()

@property (strong, nonatomic) NSArray *regexArray;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Configurar el picker view
    self.pickerView.delegate = self;
    self.pickerView.dataSource = self;
    [self.pickerView selectRow:0 inComponent:0 animated:NO];
    
    // Configurar las expresiones regulares
    self.regexArray = @[@"   ",@".*[A-Z].*", @"[A-Za-z ]+", @"\\d{10}", @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$", @"^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$", @"^(https?|ftp):\/\/[^\s\/$.?#].[^\s]*$"];
    
    // Obtiene el texto ingresado por el usuario y la expresión regular seleccionada
    NSString *textoIngresado = self.textField.text;
    NSString *expresionRegular = [_regexArray objectAtIndex:[self.pickerView selectedRowInComponent:0]];

    // Crea un objeto NSRegularExpression para la expresión regular seleccionada
    NSError *error = nil;
    NSRegularExpression *exp = [NSRegularExpression regularExpressionWithPattern:expresionRegular options:0 error:&error];

    // Verifica si el texto cumple con la expresión regular
    BOOL esValido = [exp numberOfMatchesInString:textoIngresado options:0 range:NSMakeRange(0, [textoIngresado length])] > 0;

    // Muestra el mensaje de validación correspondiente
    if (esValido) {
        NSLog(@"El texto ingresado es válido según la expresión regular seleccionada.");
    } else {
        NSLog(@"El texto ingresado no cumple con la expresión regular seleccionada.");
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    // Configurar el teclado para que se cierre cuando se toca fuera de él
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tapGesture];
}

- (void)dismissKeyboard {
    [self.textField resignFirstResponder];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    // Validar la entrada del usuario mientras escribe
    NSString *updatedText = [textField.text stringByReplacingCharactersInRange:range withString:string];
    NSRegularExpression *regex = [self selectedRegex];
    NSUInteger numberOfMatches = [regex numberOfMatchesInString:updatedText options:0 range:NSMakeRange(0, updatedText.length)];
    return (numberOfMatches > 0);
}

- (NSRegularExpression *)selectedRegex {
    NSInteger selectedRow = [self.pickerView selectedRowInComponent:0];
    NSString *regexString = self.regexArray[selectedRow];
    NSRegularExpressionOptions options = NSRegularExpressionCaseInsensitive;
    NSError *error = nil;
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:regexString options:options error:&error];
    if (error != nil) {
        NSLog(@"Error creando expresión regular: %@", error.localizedDescription);
    }
    return regex;
}

#pragma mark - UIPickerViewDataSource

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return self.regexArray.count;
}


#pragma mark - UIPickerViewDelegate

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    return self.regexArray[row];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    //Obtiene la expresion regular seleccionada
    NSString *regexString = self.regexArray[row];
    //Crea un objeto NSSRegularExpression con la expresion regular
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:regexString options:NSRegularExpressionCaseInsensitive error:nil];
    //Evalua si la cadena en el TextField cmple con la expresion regular
    BOOL isMatch = [regex numberOfMatchesInString:self.textField.text options:0 range:NSMakeRange(0, self.textField.text.length)];
    if(isMatch){
        self.validationLabel.text = @"La cadena es valida";
    }else{
        self.validationLabel.text = @"La cadena no es valida";
    }
    // Validar la entrada actual del usuario cuando el usuario selecciona una opción en el picker view
   /* NSString *input = self.textField.text;
    NSRegularExpression *regex = [self selectedRegex];
    NSUInteger numberOfMatches = [regex numberOfMatchesInString:input options:0 range:NSMakeRange(0, input.length)];
    if (numberOfMatches == 0) {
        self.textField.text = @"";*/
    
}


- (IBAction)showMessage:(id)sender {
    // Crea el controlador de alerta
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"IMPORTANTE!" message:@"Dentro de las expresiones regulares contienen cadenas vacias, validar numeros de telefonos, IP y ya sean cadenas con mayusculas y minusculas." preferredStyle:UIAlertControllerStyleAlert];
        
        // Agrega una acción para el botón "Aceptar"
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"SEGUIR CONVIRTIENDO" style:UIAlertActionStyleDefault handler:nil];
        [alert addAction:okAction];
        
        // Presenta la alerta en la vista actual
        [self presentViewController:alert animated:YES completion:nil];
}
@end
