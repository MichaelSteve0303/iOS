//
//  main.swift//  appClaseSwift
//
//  Created by Michael Steve Espinoza Perez on 19/04/23.
//

import Foundation

class Matematicas
{
    static func factorial(n: Int) -> Int
    {
        if n == 0 || n == 1
        {
            return 1;
        }
        else
        {
            return n * factorial(n: n-1);
        }
    }
    
    static func factorial(n : Double) -> Double
    {
        var f:Double = 1
        if n == 0 || n == 1
        {
            return f
        }
        for i in 1...Int(n)
        {
            f *= Double(i)
        }
        return f;
        
        
    }
    
    static func serieE() -> Double
    {
        var serie: Double = 0.0
        var i = 0
        repeat
        {
            serie += 1.0 / factorial(n: Double(i))
            i += 1
        }
        while (serie <= exp(1.0))
        return serie;
        
    }
    
   /* static func esPrimo(_ n: Int) -> Bool {
        if n <= 1 {
            return false
        }
        if n <= 3 {
            return true
        }
        if n % 2 == 0 || n % 3 == 0 {
            return false
        }
        var i = 5
        while i * i <= n {
            if n % i == 0 || n % (i + 2) == 0 {
                return false
            }
            i += 6
        }
        return true
    }*/
    
    static func esPrimo(n: Int)-> Bool{
        var esprimo = true
        var divisor = 2
        while divisor < n
        {
            if n % divisor == 0
            {
                esprimo = false
            }
            
            divisor += 1
            
        }
        return esprimo
        
    }
    
    static func encontrarPrimosEntre(minimo: Int, maximo: Int) -> [Int] {
            var primosEncontrados = [Int]()
            
            for numero in minimo...maximo {
                if esPrimo(n: numero) {
                    primosEncontrados.append(numero)
                }
            }
            
            return primosEncontrados
        }

 

    


    
   /* func calculateE() -> Double {
      let e = exp(1.0)
      return e
    }

    func calculateExponential(_ x: Double) -> Double {
      let result = exp(x)
      return result
    }*/

    //Implementar un metodo para calcular el valor de la constante e y funcion
    // exponencial.
    
}

var primosEncontrados = Matematicas.encontrarPrimosEntre(minimo: 18777500, maximo: 19777500)

print("Los números primos encontrados son: \(Matematicas.encontrarPrimosEntre(minimo: 18777500, maximo: 19777500))")
print(primosEncontrados)

//---------------------------------------------------------------------//

print("Numero: ")
var dato: String = readLine()!// ?? "5"
print("Dato capturado como String = \(dato)")
var num : Int? = Int(dato)
print("Valor Entero = \(num!)")

var factEntero = Matematicas.factorial(n: num!)
print("Factorial del Numero Entero \(num):\(factEntero)")

print("Numero :")
var dato1 : String = readLine()!
print("\n\t Dato capturado como string=\(dato1)")
var num1 : Int? = Int(dato1)
print("Valor Entero = \(num1!)")

var factDouble = Matematicas.factorial(n: num1!)
print("Factorial del Numero Entero \(num):\(factDouble)")

var serieEuler = Matematicas.serieE()
print("Valor e = \(serieEuler)")
print("Valor de e = \(Matematicas.serieE())")

var numPrimo : Int? = 18777500
//DETERMINAR LOS NUMEROS PRIMOS ENTRE
//18777500 -> 19777500

if Matematicas.esPrimo(n: numPrimo!)
{
    print("Numero \(numPrimo) es primo")
}
else
{
    print("Numero \(numPrimo) No es primo")
}




/*print("Número: ")
if let dato = readLine(), let num = Int(dato) {
    if Matematicas.esPrimo(num) {
        print("\(num) es primo.")
    } else {
        print("\(num) no es primo.")
    }
} else {
    print("Entrada inválida.")
}*/


//IMPLEMENTAR UN METODO PARA DETERMINAR SI UN NUMERO ES O NO ES PRIMO, AGREGUELO
// A LA CLASE MATEMATICAS.



// Ejemplo de uso
//let e = calculateE() // e = 2.718281828459045
//let exponentialValue = calculateExponential(2.0) // exponentialValue = 7.3890560989306495

     
